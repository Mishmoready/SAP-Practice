sap.ui.define(['sap/ui/core/UIComponent'],
	function (UIComponent) {
	"use strict";

	return UIComponent.extend("sap.ui.integration.sample.CardsLayout.Component", {

		metadata: {
			manifest: "json"
		}

	});
});